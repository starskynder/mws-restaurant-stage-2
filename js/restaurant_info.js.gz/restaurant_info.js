let restaurant, map;

/**
 * Initialize Google map, called from loadScript.
 */
window.initMap = (restaurant = self.restaurant) => {
  self.map = new google.maps.Map(document.getElementById("map"), {
    zoom: 16,
    center: restaurant.latlng,
    scrollwheel: false
  });

  self.map.addListener("tilesloaded", setMapTitle);
  DBHelper.mapMarkerForRestaurant(self.restaurant, self.map);
};

document.addEventListener("DOMContentLoaded", event => {
  fetchRestaurantFromURL((error, restaurant) => {
    if (error) {
      // Got an error!
      console.error(error);
    } else {
      fillBreadcrumb();
    }
  });
});

/**
 * Set Google Maps title and html lang
 */
setMapTitle = () => {
  const mapFrame = document.getElementById("map").querySelector("iframe");
  mapFrame.setAttribute("title", "Google maps with restaurant location");
  const htmlFrame1 = document
    .getElementById("map")
    .querySelector("iframe")
    .contentWindow.document.querySelector("html");

  
  htmlFrame1.setAttribute("lang", "en");
};
/**
 * Get current restaurant from page URL.
 */
fetchRestaurantFromURL = callback => {
  if (self.restaurant) {
    // restaurant already fetched!
    callback(null, self.restaurant);
    return;
  }
  const id = getParameterByName("id");
  if (!id) {
    // no id found in URL
    error = "No restaurant id in URL";
    callback(error, null);
  } else {
    DBHelper.fetchRestaurantById(id, (error, restaurant) => {
      self.restaurant = restaurant;
      if (!restaurant) {
        console.error(error);
        return;
      }
      fillRestaurantHTML();
      callback(null, restaurant);
    });
  }
};

/**
 * Create restaurant HTML and add it to the webpage
 */
fillRestaurantHTML = (restaurant = self.restaurant) => {
  const name = document.getElementById("restaurant-name");
  name.innerHTML = restaurant.name;

  const address = document.getElementById("restaurant-address");
  address.innerHTML = restaurant.address;

  // Set images alt attribute.
  const image = document.getElementById("restaurant-img");
  image.className = "restaurant-img lazyload";
  image.alt = `${restaurant.name} restaurant`;

  // Set images srcset  and sizes attributes.
  const imageNumber = DBHelper.imageUrlForRestaurant(restaurant);

  const setSourcet = `img/${imageNumber}-1x.jpg 1x, img/${imageNumber}-1x.webp 1x , img/${imageNumber}-2x.jpg 2x, img/${imageNumber}-2x.webp 2x`;
  image.setAttribute("data-srcset", setSourcet);
  image.setAttribute("data-sizes", "(min-width: 416px) 320px");

  image.setAttribute("data-src", `img/${imageNumber}-2x.jpg`);

  const cuisine = document.getElementById("restaurant-cuisine");
  cuisine.innerHTML = restaurant.cuisine_type;

  // fill operating hours
  if (restaurant.operating_hours) {
    fillRestaurantHoursHTML();
  }
  // fill reviews
  fillReviewsHTML();
};

/**
 * Create restaurant operating hours HTML table and add it to the webpage.
 */
fillRestaurantHoursHTML = (
  operatingHours = self.restaurant.operating_hours
) => {
  const hours = document.getElementById("restaurant-hours");
  for (let key in operatingHours) {
    const row = document.createElement("tr");

    const day = document.createElement("td");
    day.innerHTML = key;
    row.appendChild(day);

    const time = document.createElement("td");
    time.innerHTML = operatingHours[key];
    row.appendChild(time);

    hours.appendChild(row);
  }
};

/**
 * Create all reviews HTML and add them to the webpage.
 */
fillReviewsHTML = (reviews = self.restaurant.reviews) => {
  const container = document.getElementById("reviews-container");
  const title = document.createElement("h3");
  title.innerHTML = "REVIEWS";
  title.classList = "review-list_title";
  container.appendChild(title);

  if (!reviews) {
    const noReviews = document.createElement("p");
    noReviews.innerHTML = "No reviews yet!";
    container.appendChild(noReviews);
    return;
  }
  const ul = document.getElementById("reviews-list");
  reviews.forEach(review => {
    ul.appendChild(createReviewHTML(review));
  });
  container.appendChild(ul);
};

/**
 * Create review HTML and add it to the webpage.
 */
createReviewHTML = review => {
  const li = document.createElement("li");
  const name = document.createElement("p");
  name.innerHTML = review.name;
  name.classList = "reviewer";
  li.appendChild(name);

  const date = document.createElement("p");
  date.innerHTML = review.date;
  li.appendChild(date);

  const rating = document.createElement("p");
  rating.innerHTML = `Rating: ${review.rating}`;
  rating.className = "ratings";
  li.appendChild(rating);

  const comments = document.createElement("p");
  comments.innerHTML = review.comments;
  li.appendChild(comments);

  return li;
};

/**
 * Add restaurant name to the breadcrumb navigation menu
 */
fillBreadcrumb = (restaurant = self.restaurant) => {
  const breadcrumb = document.getElementById("breadcrumb");
  const li = document.createElement("li");
  li.innerHTML = restaurant.name;
  breadcrumb.appendChild(li);
};

/**
 * Get a parameter by name from page URL.
 */
getParameterByName = (name, url) => {
  if (!url) url = window.location.href;
  name = name.replace(/[\[\]]/g, "\\$&");
  const regex = new RegExp(`[?&]${name}(=([^&#]*)|&|#|$)`),
    results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return "";
  return decodeURIComponent(results[2].replace(/\+/g, " "));
};

var buttonMap = document.getElementById("hidemap");
buttonMap.addEventListener("click", loadScript, false);

// Load and Show the Map when "Click to view map" button is clicked
function loadScript() {
  var script = document.createElement("script");
  script.type = "text/javascript";
  // Please insert your Googkle Maps API_KEY here!
  script.src =
    "https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&libraries=places&callback=initMap";
  document.getElementsByTagName("head")[0].appendChild(script);
  displayMap();
  buttonMap.removeEventListener("click", loadScript, false);

  return false;
}
function displayMap() {
  document.getElementById("map-container").style.display = "block";
}
